/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import databasecontrollertest.*;
import java.awt.Toolkit;
import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author shaosh
 */
public class PatientInfo extends javax.swing.JFrame {
    private SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
    private int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
    private int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
    
    private final int PREVIOUS = -1;
    private final int STAY = 0;
    private final int NEXT = 1;
    /**
     * Creates new form PatientInfo
     */
    public PatientInfo() {
        initComponents();
//        int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//	int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	this.setLocation((screenWidth - this.getSize().width) / 2,(screenHeight - this.getSize().height) / 2); 

        Timer timer = new Timer();
        timer.schedule(new ShowTime(), new Date(), 1000);
        if(GUIController.userType == GUIController.PATIENT)
        {
            GUIController.targetlist1 = GUIController.user;
        }
        GUIController.information = DatabaseManager.getPatientInformation(GUIController.targetlist1.getID());
        updateNameAndID();
        updateBasicData();
        updateVisitData(STAY);
    }
    
    private void updateNameAndID()
    {
        patientID.setText(GUIController.targetlist1.getID());
        firstname.setText(GUIController.targetlist1.getFirstName());
        lastname.setText(GUIController.targetlist1.getLastName());
    }
    
    private void updateBasicData()
    {
        if(GUIController.information != null)
        {
            doctorIDField.setText(GUIController.information.getDoctorID());
            genderField.setText(String.valueOf(GUIController.information.getGender()));
            addrField.setText(GUIController.information.getAddress());
            contactField.setText(GUIController.information.getPhoneNumber());
            heightField.setText(String.valueOf(GUIController.information.getHeight()));
            bloodField.setText(GUIController.information.getBloodType());
            insurField.setText(GUIController.information.getInsurance());
            allergyArea.setText(GUIController.information.getAllergies());
            prescriptArea.setText(GUIController.information.getPrescriptions());
            conditionArea.setText(GUIController.information.getConditionsAndNotes());
            
            switch(GUIController.userType)
            {
                case GUIController.PATIENT:
                    doctorIDField.setEnabled(false);
                    genderField.setEnabled(false);
                    addrField.setEnabled(true);
                    contactField.setEnabled(true);
                    heightField.setEnabled(false);
                    bloodField.setEnabled(false);
                    insurField.setEnabled(true);
                    allergyArea.setEnabled(false);
                    prescriptArea.setEnabled(false);
                    conditionArea.setEnabled(false);
                    setPermissionButton.setEnabled(false);
                    break;
                case GUIController.NURSE:
                    doctorIDField.setEnabled(false);
                    genderField.setEnabled(false);
                    addrField.setEnabled(true);
                    contactField.setEnabled(true);
                    heightField.setEnabled(false);
                    bloodField.setEnabled(false);
                    insurField.setEnabled(true);
                    allergyArea.setEnabled(false);
                    prescriptArea.setEnabled(false);
                    conditionArea.setEnabled(false);
                    setPermissionButton.setEnabled(false);
                    break;
                case GUIController.DOCTOR:
                    doctorIDField.setEnabled(true);
                    genderField.setEnabled(false);
                    addrField.setEnabled(true);
                    contactField.setEnabled(true);
                    heightField.setEnabled(false);
                    bloodField.setEnabled(false);
                    insurField.setEnabled(true);
                    allergyArea.setEnabled(true);
                    prescriptArea.setEnabled(true);
                    conditionArea.setEnabled(true);
                    setPermissionButton.setEnabled(true);
                    break;
                default:
                    GUIController.user = null;
                    GUIController.machineState = GUIController.LAUNCH;
                    JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                    break;
            }
        }
        else
        {
            System.out.println("There is no basic data.");
            doctorIDField.setText("");
            genderField.setText("");
            addrField.setText("");
            contactField.setText("");
            heightField.setText("");
            bloodField.setText("");
            insurField.setText("");
            allergyArea.setText("");
            prescriptArea.setText("");
            conditionArea.setText("");
            
            switch(GUIController.userType)
            {
                case GUIController.PATIENT:
                    break;
                case GUIController.NURSE:
                    doctorIDField.setEnabled(true);
                    genderField.setEnabled(true);
                    addrField.setEnabled(true);
                    contactField.setEnabled(true);
                    heightField.setEnabled(true);
                    bloodField.setEnabled(true);
                    insurField.setEnabled(true);
                    allergyArea.setEnabled(false);
                    prescriptArea.setEnabled(false);
                    conditionArea.setEnabled(false);
                    setPermissionButton.setEnabled(false);
                    break;
                case GUIController.DOCTOR:
                    doctorIDField.setEnabled(true);
                    genderField.setEnabled(true);
                    addrField.setEnabled(true);
                    contactField.setEnabled(true);
                    heightField.setEnabled(true);
                    bloodField.setEnabled(true);
                    insurField.setEnabled(true);
                    allergyArea.setEnabled(true);
                    prescriptArea.setEnabled(true);
                    conditionArea.setEnabled(true);
                    setPermissionButton.setEnabled(false);
                    break;
                default:
                    GUIController.user = null;
                    GUIController.machineState = GUIController.LAUNCH;
                    JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                    break;
            }
        }
    }
    
    private void updateVisitData(int toggle)
    {
        if(GUIController.currentVisit != null)
        {
            GUIController.visitList = GUIController.currentVisit;
        }
        if(GUIController.visitList != null)
        {
            switch(toggle)
            {
                case PREVIOUS:
                    GUIController.currentVisit = GUIController.visitList.getPrevious();
                    break;
                case STAY:
                    break;
                case NEXT:
                    GUIController.currentVisit = GUIController.visitList.getNext();
                    break;
                default:
                    //if this happens, something is wrong.
                    break;
            }
        }
        if(GUIController.currentVisit != null)
        {
            confirmButton2.setEnabled(false);
            if(GUIController.userType == GUIController.DOCTOR)
            {
                markInvalidButton.setEnabled(true);
            }
            else
            {
                markInvalidButton.setEnabled(false);
            }
            if(GUIController.userType == GUIController.NURSE)
            {
                nextButton.setEnabled(false);
            }
            else
            {
                nextButton.setEnabled(true);
            }
            if(GUIController.currentVisit.getPrevious() == null ||
                    GUIController.userType == GUIController.NURSE)
            {
                prevButton.setEnabled(false);
            }
            else
            {
                prevButton.setEnabled(true);
            }
            visitDate.setText(GUIController.currentVisit.getDate());
            visitDate.setEnabled(false);
            preasureField.setText(String.valueOf(GUIController.currentVisit.getBloodPreasure()));
            preasureField.setEnabled(false);
            tempField.setText(String.valueOf(GUIController.currentVisit.getTemperature()));
            tempField.setEnabled(false);
            weightField.setText(String.valueOf(GUIController.currentVisit.getWeight()));
            weightField.setEnabled(false);
            complainArea.setText(GUIController.currentVisit.getComplaints());
            complainArea.setEnabled(false);
            observeArea.setText(GUIController.currentVisit.getDoctorNotes());
            observeArea.setEnabled(false);
            mediArea.setText(GUIController.currentVisit.getMedication());
            mediArea.setEnabled(false);
            actionsArea.setText(GUIController.currentVisit.getDoctorActions());
            actionsArea.setEnabled(false);
        }
        else
        {
            
            markInvalidButton.setEnabled(false);
            nextButton.setEnabled(false);
            if(GUIController.userType == GUIController.NURSE)
            {
                nextButton.setEnabled(false);
            }
            else
            {
                nextButton.setEnabled(true);
            }
            switch(GUIController.userType)
            {
                case GUIController.PATIENT:
                    if(GUIController.information != null && (GUIController.information.getBloodPermissions() ||
                            GUIController.information.getWeightPermissions() || GUIController.information.getTemperaturePermssions()))
                    {
                        confirmButton2.setEnabled(true);
                        if(GUIController.information.getBloodPermissions())
                        {
                            preasureField.setEnabled(true);
                        }
                        else
                        {
                            preasureField.setEnabled(false);
                        }
                        if(GUIController.information.getTemperaturePermssions())
                        {
                            tempField.setEnabled(true);
                        }
                        else
                        {
                            tempField.setEnabled(false);
                        }
                        if(GUIController.information.getWeightPermissions())
                        {
                            weightField.setEnabled(true);
                        }
                        else
                        {
                            weightField.setEnabled(false);
                        }
                        complainArea.setEnabled(true);
                        mediArea.setEnabled(true);
                    }
                    else
                    {
                        confirmButton2.setEnabled(false);
                        preasureField.setEnabled(false);
                        tempField.setEnabled(false);
                        weightField.setEnabled(false);
                        complainArea.setEnabled(false);
                        mediArea.setEnabled(false);
                    }
                    observeArea.setEnabled(false);
                    actionsArea.setEnabled(false);
                    break;
                case GUIController.NURSE:
                    confirmButton2.setEnabled(false);
                    preasureField.setEnabled(false);
                    tempField.setEnabled(false);
                    weightField.setEnabled(false);
                    complainArea.setEnabled(false);
                    observeArea.setEnabled(false);
                    mediArea.setEnabled(false);
                    actionsArea.setEnabled(false);
                    break;
                case GUIController.DOCTOR:
                    confirmButton2.setEnabled(true);
                    preasureField.setEnabled(true);
                    tempField.setEnabled(true);
                    weightField.setEnabled(true);
                    complainArea.setEnabled(true);
                    observeArea.setEnabled(true);
                    mediArea.setEnabled(true);
                    actionsArea.setEnabled(true);
                    break;
            }
            visitDate.setText("");
            preasureField.setText("");
            tempField.setText("");
            weightField.setText("");
            complainArea.setText("");
            observeArea.setText("");
            mediArea.setText("");
            actionsArea.setText("");
        }
    }
    
    class ShowTime extends TimerTask{
        @Override
        public void run(){
            datetime.setText(sdf.format(new Date()));
            repaint();
        }
    }
    
    public void PatientInfoVisible(){
        this.setVisible(true);		
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        completeDialog = new javax.swing.JDialog();
        completePanel = new javax.swing.JPanel();
        completeButton = new javax.swing.JButton();
        completeLabel = new javax.swing.JLabel();
        setPermissionDialog = new javax.swing.JDialog();
        setPermissionPanel = new javax.swing.JPanel();
        patientLabel2 = new javax.swing.JLabel();
        patientName = new javax.swing.JLabel();
        doctorLabel2 = new javax.swing.JLabel();
        doctorName = new javax.swing.JLabel();
        tempCheck = new javax.swing.JCheckBox();
        sugarCheck = new javax.swing.JCheckBox();
        weightCheck = new javax.swing.JCheckBox();
        cancelButton3 = new javax.swing.JButton();
        grantButton = new javax.swing.JButton();
        tabbedPane = new javax.swing.JTabbedPane();
        basicPanel = new javax.swing.JPanel();
        lastLabel = new javax.swing.JLabel();
        lastname = new javax.swing.JLabel();
        firstLabel = new javax.swing.JLabel();
        firstname = new javax.swing.JLabel();
        genderLabel = new javax.swing.JLabel();
        addrLabel = new javax.swing.JLabel();
        contactLabel = new javax.swing.JLabel();
        genderField = new javax.swing.JTextField();
        addrField = new javax.swing.JTextField();
        heightLabel = new javax.swing.JLabel();
        bloodLabel = new javax.swing.JLabel();
        heightField = new javax.swing.JTextField();
        bloodField = new javax.swing.JTextField();
        insurLabel = new javax.swing.JLabel();
        insurField = new javax.swing.JTextField();
        allergyLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        allergyArea = new javax.swing.JTextArea();
        confirmButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        contactField = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        prescriptArea = new javax.swing.JTextArea();
        prescriptLabel = new javax.swing.JLabel();
        doctorIDField = new javax.swing.JTextField();
        doctorIDLable = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        conditionArea = new javax.swing.JTextArea();
        conditionLable = new javax.swing.JLabel();
        setPermissionButton = new javax.swing.JButton();
        healthPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        mediArea = new javax.swing.JTextArea();
        mediLabel = new javax.swing.JLabel();
        visitLabel = new javax.swing.JLabel();
        visitDate = new javax.swing.JLabel();
        tempLabel = new javax.swing.JLabel();
        preasureLabel = new javax.swing.JLabel();
        tempField = new javax.swing.JTextField();
        complainLabel = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        complainArea = new javax.swing.JTextArea();
        observeLabel = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        observeArea = new javax.swing.JTextArea();
        prevButton = new javax.swing.JButton();
        nextButton = new javax.swing.JButton();
        markInvalidButton = new javax.swing.JButton();
        confirmButton2 = new javax.swing.JButton();
        cancelButton2 = new javax.swing.JButton();
        preasureField = new javax.swing.JTextField();
        weightField = new javax.swing.JTextField();
        weightLabel = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        actionsArea = new javax.swing.JTextArea();
        actionsLable = new javax.swing.JLabel();
        patientIDLabel = new javax.swing.JLabel();
        patientID = new javax.swing.JLabel();
        datetime = new javax.swing.JLabel();

        completeDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        completeDialog.setTitle("Attention");
        completeDialog.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        completeDialog.setIconImage(null);
        completeDialog.setName("completeDialog"); // NOI18N
        completeDialog.getContentPane().setLayout(null);

        completePanel.setMaximumSize(new java.awt.Dimension(285, 190));
        completePanel.setPreferredSize(new java.awt.Dimension(285, 190));
        completePanel.setLayout(null);

        completeButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        completeButton.setText("Confirm");
        completeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeButtonActionPerformed(evt);
            }
        });
        completePanel.add(completeButton);
        completeButton.setBounds(90, 100, 100, 30);

        completeLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        completePanel.add(completeLabel);
        completeLabel.setBounds(60, 40, 160, 30);

        completeDialog.getContentPane().add(completePanel);
        completePanel.setBounds(0, 0, 285, 190);

        setPermissionDialog.setTitle("Set Permission");
        setPermissionDialog.getContentPane().setLayout(null);

        setPermissionPanel.setLayout(null);

        patientLabel2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientLabel2.setText("Patient:");
        setPermissionPanel.add(patientLabel2);
        patientLabel2.setBounds(60, 30, 50, 18);

        patientName.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientName.setText("PatientName");
        setPermissionPanel.add(patientName);
        patientName.setBounds(120, 30, 80, 18);

        doctorLabel2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        doctorLabel2.setText("Doctor:");
        setPermissionPanel.add(doctorLabel2);
        doctorLabel2.setBounds(260, 30, 50, 18);

        doctorName.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        doctorName.setText("DoctorName");
        setPermissionPanel.add(doctorName);
        doctorName.setBounds(310, 30, 70, 18);

        tempCheck.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        tempCheck.setText("Temperature");
        setPermissionPanel.add(tempCheck);
        tempCheck.setBounds(60, 70, 110, 27);

        sugarCheck.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        sugarCheck.setText("Blood  Preasure");
        sugarCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sugarCheckActionPerformed(evt);
            }
        });
        setPermissionPanel.add(sugarCheck);
        sugarCheck.setBounds(60, 110, 120, 27);

        weightCheck.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        weightCheck.setText("Weight");
        setPermissionPanel.add(weightCheck);
        weightCheck.setBounds(260, 110, 70, 27);

        cancelButton3.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cancelButton3.setText("Cancel");
        cancelButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton3ActionPerformed(evt);
            }
        });
        setPermissionPanel.add(cancelButton3);
        cancelButton3.setBounds(130, 210, 130, 30);

        grantButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        grantButton.setText("Grant Permission");
        grantButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grantButtonActionPerformed(evt);
            }
        });
        setPermissionPanel.add(grantButton);
        grantButton.setBounds(130, 160, 130, 30);

        setPermissionDialog.getContentPane().add(setPermissionPanel);
        setPermissionPanel.setBounds(0, 0, 400, 300);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Visit Record");
        setMinimumSize(new java.awt.Dimension(450, 700));
        setPreferredSize(new java.awt.Dimension(450, 700));
        setResizable(false);
        getContentPane().setLayout(null);

        tabbedPane.setMinimumSize(new java.awt.Dimension(45, 44));
        tabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tabbedPaneMouseReleased(evt);
            }
        });

        basicPanel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.setLayout(null);

        lastLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        lastLabel.setText("Last Name");
        basicPanel.add(lastLabel);
        lastLabel.setBounds(20, 10, 75, 20);

        lastname.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        lastname.setText("lastname");
        basicPanel.add(lastname);
        lastname.setBounds(95, 10, 100, 20);

        firstLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        firstLabel.setText("First Name ");
        basicPanel.add(firstLabel);
        firstLabel.setBounds(210, 10, 75, 20);

        firstname.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        firstname.setText("firstname");
        basicPanel.add(firstname);
        firstname.setBounds(290, 10, 100, 20);

        genderLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        genderLabel.setText("Gender ");
        basicPanel.add(genderLabel);
        genderLabel.setBounds(230, 50, 50, 20);

        addrLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        addrLabel.setText("Address");
        basicPanel.add(addrLabel);
        addrLabel.setBounds(20, 95, 75, 20);

        contactLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        contactLabel.setText("Contact");
        basicPanel.add(contactLabel);
        contactLabel.setBounds(230, 95, 75, 20);

        genderField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        genderField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderFieldActionPerformed(evt);
            }
        });
        basicPanel.add(genderField);
        genderField.setBounds(280, 50, 40, 30);

        addrField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(addrField);
        addrField.setBounds(70, 90, 140, 30);

        heightLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        heightLabel.setText("Height(cm)");
        basicPanel.add(heightLabel);
        heightLabel.setBounds(20, 155, 75, 20);

        bloodLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        bloodLabel.setText("Blood Type");
        basicPanel.add(bloodLabel);
        bloodLabel.setBounds(300, 155, 75, 20);

        heightField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(heightField);
        heightField.setBounds(90, 150, 45, 30);

        bloodField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(bloodField);
        bloodField.setBounds(370, 150, 40, 30);

        insurLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        insurLabel.setText("Insurance");
        basicPanel.add(insurLabel);
        insurLabel.setBounds(20, 215, 75, 20);

        insurField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(insurField);
        insurField.setBounds(90, 210, 180, 30);

        allergyLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        allergyLabel.setText("Allergy");
        basicPanel.add(allergyLabel);
        allergyLabel.setBounds(20, 280, 75, 20);

        allergyArea.setColumns(20);
        allergyArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        allergyArea.setRows(5);
        jScrollPane1.setViewportView(allergyArea);

        basicPanel.add(jScrollPane1);
        jScrollPane1.setBounds(90, 280, 320, 60);

        confirmButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        confirmButton.setText("Confirm");
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });
        basicPanel.add(confirmButton);
        confirmButton.setBounds(190, 500, 100, 30);

        cancelButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        basicPanel.add(cancelButton);
        cancelButton.setBounds(310, 500, 100, 30);

        contactField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(contactField);
        contactField.setBounds(280, 90, 130, 30);

        prescriptArea.setColumns(20);
        prescriptArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        prescriptArea.setRows(5);
        jScrollPane5.setViewportView(prescriptArea);

        basicPanel.add(jScrollPane5);
        jScrollPane5.setBounds(90, 350, 320, 60);

        prescriptLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        prescriptLabel.setText("Prescription");
        basicPanel.add(prescriptLabel);
        prescriptLabel.setBounds(20, 350, 80, 20);

        doctorIDField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(doctorIDField);
        doctorIDField.setBounds(70, 50, 140, 30);

        doctorIDLable.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        doctorIDLable.setText("Dr ID");
        basicPanel.add(doctorIDLable);
        doctorIDLable.setBounds(20, 50, 75, 20);

        conditionArea.setColumns(20);
        conditionArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        conditionArea.setRows(5);
        jScrollPane6.setViewportView(conditionArea);

        basicPanel.add(jScrollPane6);
        jScrollPane6.setBounds(90, 420, 320, 60);

        conditionLable.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        conditionLable.setText("Conditions");
        basicPanel.add(conditionLable);
        conditionLable.setBounds(20, 420, 80, 30);

        setPermissionButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        setPermissionButton.setText("Set Permission");
        setPermissionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setPermissionButtonActionPerformed(evt);
            }
        });
        basicPanel.add(setPermissionButton);
        setPermissionButton.setBounds(60, 500, 120, 30);

        tabbedPane.addTab("Basic", basicPanel);

        healthPanel.setLayout(null);

        mediArea.setColumns(20);
        mediArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        mediArea.setRows(5);
        jScrollPane2.setViewportView(mediArea);

        healthPanel.add(jScrollPane2);
        jScrollPane2.setBounds(110, 270, 310, 70);

        mediLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        mediLabel.setText("Medication");
        healthPanel.add(mediLabel);
        mediLabel.setBounds(20, 270, 75, 20);

        visitLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        visitLabel.setText("Visit Date");
        healthPanel.add(visitLabel);
        visitLabel.setBounds(20, 10, 70, 20);

        visitDate.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        visitDate.setText("MM-DD-YYYY");
        healthPanel.add(visitDate);
        visitDate.setBounds(90, 10, 330, 18);

        tempLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        tempLabel.setText("Temperature(C)");
        healthPanel.add(tempLabel);
        tempLabel.setBounds(190, 50, 85, 18);

        preasureLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        preasureLabel.setText("Blood Pressure mmHg");
        healthPanel.add(preasureLabel);
        preasureLabel.setBounds(20, 50, 130, 20);

        tempField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        healthPanel.add(tempField);
        tempField.setBounds(280, 50, 30, 30);

        complainLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        complainLabel.setText("Complaints");
        healthPanel.add(complainLabel);
        complainLabel.setBounds(20, 85, 70, 20);

        complainArea.setColumns(20);
        complainArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        complainArea.setRows(5);
        jScrollPane3.setViewportView(complainArea);

        healthPanel.add(jScrollPane3);
        jScrollPane3.setBounds(110, 90, 310, 70);

        observeLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        observeLabel.setText("Observation");
        healthPanel.add(observeLabel);
        observeLabel.setBounds(20, 180, 70, 20);

        observeArea.setColumns(20);
        observeArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        observeArea.setRows(5);
        jScrollPane4.setViewportView(observeArea);

        healthPanel.add(jScrollPane4);
        jScrollPane4.setBounds(110, 180, 310, 70);

        prevButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        prevButton.setText("<< Previous");
        prevButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevButtonActionPerformed(evt);
            }
        });
        healthPanel.add(prevButton);
        prevButton.setBounds(10, 550, 120, 30);

        nextButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        nextButton.setText("Next >>");
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        healthPanel.add(nextButton);
        nextButton.setBounds(310, 550, 120, 30);

        markInvalidButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        markInvalidButton.setText("Mark Invalid");
        markInvalidButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                markInvalidButtonActionPerformed(evt);
            }
        });
        healthPanel.add(markInvalidButton);
        markInvalidButton.setBounds(160, 500, 120, 30);

        confirmButton2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        confirmButton2.setText("Confirm");
        confirmButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButton2ActionPerformed(evt);
            }
        });
        healthPanel.add(confirmButton2);
        confirmButton2.setBounds(310, 500, 120, 30);

        cancelButton2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cancelButton2.setText("Cancel");
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });
        healthPanel.add(cancelButton2);
        cancelButton2.setBounds(10, 500, 120, 30);

        preasureField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        healthPanel.add(preasureField);
        preasureField.setBounds(150, 50, 30, 30);

        weightField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        healthPanel.add(weightField);
        weightField.setBounds(390, 50, 30, 30);

        weightLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        weightLabel.setText("Weight(kg)");
        healthPanel.add(weightLabel);
        weightLabel.setBounds(320, 50, 75, 20);

        actionsArea.setColumns(20);
        actionsArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        actionsArea.setRows(5);
        jScrollPane7.setViewportView(actionsArea);

        healthPanel.add(jScrollPane7);
        jScrollPane7.setBounds(110, 360, 310, 70);

        actionsLable.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        actionsLable.setText("Actions");
        healthPanel.add(actionsLable);
        actionsLable.setBounds(20, 360, 75, 20);

        tabbedPane.addTab("Health", healthPanel);

        getContentPane().add(tabbedPane);
        tabbedPane.setBounds(0, 30, 450, 620);

        patientIDLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientIDLabel.setText("Patient ID:");
        patientIDLabel.setToolTipText("");
        getContentPane().add(patientIDLabel);
        patientIDLabel.setBounds(30, 10, 70, 18);

        patientID.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientID.setText("PatientID");
        getContentPane().add(patientID);
        patientID.setBounds(100, 10, 100, 18);

        datetime.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        datetime.setText("MM-DD-YYYY HH:MM:SS");
        getContentPane().add(datetime);
        datetime.setBounds(240, 10, 160, 18);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
//        int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//        int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        if(GUIController.information == null)
        {
            if(GUIController.userType == GUIController.PATIENT)
            {                    
                JOptionPane.showMessageDialog(null, "Please see staff to set up account!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                GUIController.machineState = GUIController.PATIENTMAIN;
                PatientMain patientMain = new PatientMain();
                patientMain.PatientMainVisible();
                this.dispose();
                return;
            }
            if(DatabaseManager.find(doctorIDField.getText(),null,null,GUIController.DOCTOR) != null)
            {
                DatabaseManager.inputPatientInfo(GUIController.targetlist1.getID(),
                        genderField.getText().charAt(0),
                        Float.parseFloat(heightField.getText()),
                        allergyArea.getText(),
                        prescriptArea.getText(),
                        conditionArea.getText(),
                        bloodField.getText(),
                        insurField.getText(),
                        addrField.getText(),
                        contactField.getText(),
                        doctorIDField.getText(),
                        false, false, false);
            }
            else
            {
                 JOptionPane.showMessageDialog(null, "Please enter a doctor!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else
        {
            DatabaseManager.updateAddress(GUIController.targetlist1.getID(), addrField.getText());
            DatabaseManager.updateAllergies(GUIController.targetlist1.getID(), allergyArea.getText());
            DatabaseManager.updateConditionsAndNotes(GUIController.targetlist1.getID(), conditionArea.getText());
            if(DatabaseManager.find(doctorIDField.getText(),null,null,GUIController.DOCTOR) != null)
            {
                DatabaseManager.updateDoctor(GUIController.targetlist1.getID(), doctorIDField.getText());
            }
            else
            {
                 JOptionPane.showMessageDialog(null, "Please enter a doctor!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
            }
            DatabaseManager.updateInsurance(GUIController.targetlist1.getID(), insurField.getText());
            DatabaseManager.updatePrescriptions(GUIController.targetlist1.getID(), prescriptArea.getText());
        }
        GUIController.information = DatabaseManager.getPatientInformation(GUIController.targetlist1.getID());
        completeDialog.setSize(285, 190);
        completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
        completeLabel.setText("Database update complete.");
        completeDialog.setVisible(true);
        updateBasicData();
    }//GEN-LAST:event_confirmButtonActionPerformed

    private void completeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completeButtonActionPerformed
        completeDialog.dispose();
    }//GEN-LAST:event_completeButtonActionPerformed

    private void confirmButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButton2ActionPerformed
//        int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//        int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        DatabaseManager.inputVisitData(GUIController.targetlist1.getID(),
                Float.parseFloat(preasureField.getText()),
                Float.parseFloat(tempField.getText()),
                Float.parseFloat(weightField.getText()),
                mediArea.getText(),
                complainArea.getText(),
                observeArea.getText(),
                actionsArea.getText());
        completeDialog.setSize(285, 190);
        completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
        completeLabel.setText("Database update complete.");
        GUIController.targetlist1 = null;
        GUIController.targetlist2 = null;
        GUIController.visitList = null;
        GUIController.information = null;
        switch(GUIController.userType)
        {
            case GUIController.ADMIN:
                GUIController.machineState = GUIController.ADMINMAIN;
                AdminMain adminMain = new AdminMain();
                adminMain.AdminMainVisible();
                break;
            case GUIController.DOCTOR:
                GUIController.machineState = GUIController.DOCTORMAIN;
                DoctorMain doctorMain = new DoctorMain();
                doctorMain.DoctorMainVisible();
                break;
            case GUIController.NURSE:
                GUIController.machineState = GUIController.NURSEMAIN;
                NurseMain nurseMain = new NurseMain();
                nurseMain.NurseMainVisible();
                break;
            case GUIController.PATIENT:
                GUIController.machineState = GUIController.PATIENTMAIN;
                PatientMain patientMain = new PatientMain();
                patientMain.PatientMainVisible();
                break;
            default:
                GUIController.user = null;
                GUIController.machineState = GUIController.LAUNCH;
                JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
        completeDialog.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_confirmButton2ActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        GUIController.targetlist1 = null;
        GUIController.targetlist2 = null;
        GUIController.visitList = null;
        GUIController.information = null;
        switch(GUIController.userType)
        {
            case GUIController.ADMIN:
                GUIController.machineState = GUIController.ADMINMAIN;
                AdminMain adminMain = new AdminMain();
                adminMain.AdminMainVisible();
                break;
            case GUIController.DOCTOR:
                GUIController.machineState = GUIController.DOCTORMAIN;
                DoctorMain doctorMain = new DoctorMain();
                doctorMain.DoctorMainVisible();
                break;
            case GUIController.NURSE:
                GUIController.machineState = GUIController.NURSEMAIN;
                NurseMain nurseMain = new NurseMain();
                nurseMain.NurseMainVisible();
                break;
            case GUIController.PATIENT:
                GUIController.machineState = GUIController.PATIENTMAIN;
                PatientMain patientMain = new PatientMain();
                patientMain.setVisible(true);
                break;
            default:
                GUIController.user = null;
                GUIController.machineState = GUIController.LAUNCH;
                JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
        this.dispose();
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
        GUIController.targetlist1 = null;
        GUIController.targetlist2 = null;
        GUIController.visitList = null;
        GUIController.information = null;
        switch(GUIController.userType)
        {
            case GUIController.ADMIN:
                GUIController.machineState = GUIController.ADMINMAIN;
                AdminMain adminMain = new AdminMain();
                adminMain.AdminMainVisible();
                break;
            case GUIController.DOCTOR:
                GUIController.machineState = GUIController.DOCTORMAIN;
                DoctorMain doctorMain = new DoctorMain();
                doctorMain.DoctorMainVisible();
                break;
            case GUIController.NURSE:
                GUIController.machineState = GUIController.NURSEMAIN;
                NurseMain nurseMain = new NurseMain();
                nurseMain.NurseMainVisible();
                break;
            case GUIController.PATIENT:
                GUIController.machineState = GUIController.PATIENTMAIN;
                PatientMain patientMain = new PatientMain();
                patientMain.setVisible(true);
                break;
            default:
                GUIController.user = null;
                GUIController.machineState = GUIController.LAUNCH;
                JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
        this.dispose();
    }//GEN-LAST:event_cancelButton2ActionPerformed

    private void grantButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grantButtonActionPerformed
        if(tempCheck.isSelected()||sugarCheck.isSelected()||weightCheck.isSelected()){
            DatabaseManager.updateSubmissionPermissions(GUIController.targetlist1.getID(), sugarCheck.isSelected(), tempCheck.isSelected(), weightCheck.isSelected());
            completeDialog.setSize(285, 190);
            completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
            completeLabel.setText("Permission is granted.");
            completeDialog.setVisible(true);
            setPermissionDialog.setVisible(false);
        }
        else{
            JOptionPane.showMessageDialog(null, "Please check at least one indicator!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_grantButtonActionPerformed

    private void cancelButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton3ActionPerformed
        setPermissionDialog.dispose();
    }//GEN-LAST:event_cancelButton3ActionPerformed

    private void markInvalidButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_markInvalidButtonActionPerformed
        if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWHISTORY)
        {
            DatabaseManager.markVisitValidity(GUIController.targetlist1.getID(), GUIController.visitList.getDate(), false);
            completeDialog.setSize(285, 190);
            completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
            completeLabel.setText("Marking invalid complete.");
            completeDialog.setVisible(true);
        }
    }//GEN-LAST:event_markInvalidButtonActionPerformed

    private void setPermissionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setPermissionButtonActionPerformed
      if(GUIController.information != null)
      {
            sugarCheck.setSelected(GUIController.information.getBloodPermissions());
            tempCheck.setSelected(GUIController.information.getTemperaturePermssions());
            weightCheck.setSelected(GUIController.information.getWeightPermissions());
            setPermissionDialog.setSize(450, 300);
            setPermissionDialog.setLocation((screenWidth - setPermissionDialog.getSize().width) / 2,(screenHeight - setPermissionDialog.getSize().height) / 2);            
            setPermissionDialog.setVisible(true);
      }
    }//GEN-LAST:event_setPermissionButtonActionPerformed

    private void tabbedPaneMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabbedPaneMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tabbedPaneMouseReleased

    private void genderFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderFieldActionPerformed

    private void sugarCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sugarCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sugarCheckActionPerformed

    private void prevButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevButtonActionPerformed
        updateVisitData(PREVIOUS);
    }//GEN-LAST:event_prevButtonActionPerformed

    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        updateVisitData(NEXT);
    }//GEN-LAST:event_nextButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea actionsArea;
    private javax.swing.JLabel actionsLable;
    private javax.swing.JTextField addrField;
    private javax.swing.JLabel addrLabel;
    private javax.swing.JTextArea allergyArea;
    private javax.swing.JLabel allergyLabel;
    private javax.swing.JPanel basicPanel;
    private javax.swing.JTextField bloodField;
    private javax.swing.JLabel bloodLabel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JButton cancelButton3;
    private javax.swing.JTextArea complainArea;
    private javax.swing.JLabel complainLabel;
    private javax.swing.JButton completeButton;
    private javax.swing.JDialog completeDialog;
    private javax.swing.JLabel completeLabel;
    private javax.swing.JPanel completePanel;
    private javax.swing.JTextArea conditionArea;
    private javax.swing.JLabel conditionLable;
    private javax.swing.JButton confirmButton;
    private javax.swing.JButton confirmButton2;
    private javax.swing.JTextField contactField;
    private javax.swing.JLabel contactLabel;
    private javax.swing.JLabel datetime;
    private javax.swing.JTextField doctorIDField;
    private javax.swing.JLabel doctorIDLable;
    private javax.swing.JLabel doctorLabel2;
    private javax.swing.JLabel doctorName;
    private javax.swing.JLabel firstLabel;
    private javax.swing.JLabel firstname;
    private javax.swing.JTextField genderField;
    private javax.swing.JLabel genderLabel;
    private javax.swing.JButton grantButton;
    private javax.swing.JPanel healthPanel;
    private javax.swing.JTextField heightField;
    private javax.swing.JLabel heightLabel;
    private javax.swing.JTextField insurField;
    private javax.swing.JLabel insurLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lastLabel;
    private javax.swing.JLabel lastname;
    private javax.swing.JButton markInvalidButton;
    private javax.swing.JTextArea mediArea;
    private javax.swing.JLabel mediLabel;
    private javax.swing.JButton nextButton;
    private javax.swing.JTextArea observeArea;
    private javax.swing.JLabel observeLabel;
    private javax.swing.JLabel patientID;
    private javax.swing.JLabel patientIDLabel;
    private javax.swing.JLabel patientLabel2;
    private javax.swing.JLabel patientName;
    private javax.swing.JTextField preasureField;
    private javax.swing.JLabel preasureLabel;
    private javax.swing.JTextArea prescriptArea;
    private javax.swing.JLabel prescriptLabel;
    private javax.swing.JButton prevButton;
    private javax.swing.JButton setPermissionButton;
    private javax.swing.JDialog setPermissionDialog;
    private javax.swing.JPanel setPermissionPanel;
    private javax.swing.JCheckBox sugarCheck;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JCheckBox tempCheck;
    private javax.swing.JTextField tempField;
    private javax.swing.JLabel tempLabel;
    private javax.swing.JLabel visitDate;
    private javax.swing.JLabel visitLabel;
    private javax.swing.JCheckBox weightCheck;
    private javax.swing.JTextField weightField;
    private javax.swing.JLabel weightLabel;
    // End of variables declaration//GEN-END:variables
}
