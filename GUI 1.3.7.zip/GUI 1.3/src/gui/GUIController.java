/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import databasecontrollertest.*;

/**
 *
 * @author G1bz
 */
public class GUIController {
    //user types
    public static  final int NOUSER = -1;
    public static final int PATIENT = 0;
    public static final int NURSE = 1;
    public static final int DOCTOR = 2;
    public static final int ADMIN = 3;
    
    //machine states
    public static final int LAUNCH = -1;
    public static final int STARTUP = 0;
    public static final int LOGIN = 1;
    public static final int LOGINCHANGEPASSWORD = 10;
    public static final int PATIENTMAIN = 2;
    public static final int PATIENTHISTORY = 20;
    public static final int PATIENTUPDATE = 21;
    public static final int NURSEMAIN = 3;
    public static final int NURSECREATEPATIENT = 30;
    public static final int NURSECREATEPATIENTDATA = 300;
    public static final int NURSEFIND = 31;
    public static final int NURSEFINDMERGE = 310;
    public static final int NURSEFINDASSIGN = 311;
    public static final int NURSEPATIENTLIST = 32;
    public static final int NURSEPATIENTINFO = 33;
    public static final int DOCTORMAIN = 4;
    public static final int DOCTORCREATEPATIENT = 40;
    public static final int DOCTORCREATEPATIENTDATA = 400;
    public static final int DOCTORHEALTHVIEWNEW = 410;
    public static final int DOCTORHEALTHVIEWHISTORY = 411;
    public static final int DOCTORFIND = 41;
    public static final int DOCTORFINDMERGE = 410;
    public static final int DOCTORFINDASSIGN = 411;
    public static final int DOCTORPATIENTLIST = 42;
    public static final int DOCTORPATIENTINFO = 43;
    public static final int ADMINMAIN = 5;
    public static final int ADMINCREATEADMIN = 50;
    public static final int ADMINCREATEDOCTOR = 51;
    public static final int ADMINCREATENURSE = 52;
    public static final int ADMINFIND = 54;
    public static final int ADMINFINDMERGE = 540;
    public static final int ADMINFINDASSIGN = 541;
    public static final int ADMINUSERLIST = 55;
    public static final int EXIT = -2;
    
    //Static data
    public static int userType = -1;
    public static int machineState = -1;
    public static LinkedLoginData user = null;
    public static LinkedLoginData targetlist1 = null;
    public static LinkedLoginData targetlist2 = null;
    public static LinkedPatientInformation information = null;
    public static LinkedVisitData visitList = null;
    public static LinkedVisitData currentVisit = null;
}
