/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import databasecontrollertest.*;
import java.awt.Toolkit;
import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author shaosh
 */
public class PatientInfo extends javax.swing.JFrame {
    private SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
    private int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
    private int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
    /**
     * Creates new form PatientInfo
     */
    public PatientInfo() {
        initComponents();
//        int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//	int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	this.setLocation((screenWidth - this.getSize().width) / 2,(screenHeight - this.getSize().height) / 2); 

        Timer timer = new Timer();
        timer.schedule(new ShowTime(), new Date(), 1000);
        if(GUIController.userType == GUIController.PATIENT)
        {
            GUIController.targetlist1 = GUIController.user;
        }
        if(GUIController.targetlist1 != null)
        {
            patientID.setText(GUIController.targetlist1.getID());
            lastname.setText(GUIController.targetlist1.getLastName());
            firstname.setText(GUIController.targetlist1.getFirstName());
            GUIController.information = DatabaseManager.getPatientInformation(GUIController.targetlist1.getID());
            if(GUIController.information != null)
            {
                genderField.setText(String.valueOf(GUIController.information.getGender()));
                genderField.setEditable(false);
                addrField.setText(GUIController.information.getAddress());
                contactField.setText(GUIController.information.getConditionsAndNotes());
                heightField.setText(String.valueOf(GUIController.information.getHeight()));
                bloodField.setText(GUIController.information.getBloodType());
                bloodField.setEditable(false);
                insurField.setText(GUIController.information.getInsurance());
                allergyArea.setText(GUIController.information.getAllergies());
                prescriptArea.setText(GUIController.information.getPrescriptions());
            }
        }
        else
        {
            GUIController.targetlist1 = null;
            GUIController.targetlist2 = null;
            GUIController.visitList = null;
            switch(GUIController.userType)
            {
                case GUIController.ADMIN:
                    GUIController.machineState = GUIController.ADMINMAIN;
                    AdminMain adminMain = new AdminMain();
                    adminMain.AdminMainVisible();
                    break;
                case GUIController.DOCTOR:
                    GUIController.machineState = GUIController.DOCTORMAIN;
                    DoctorMain doctorMain = new DoctorMain();
                    doctorMain.DoctorMainVisible();
                    break;
                case GUIController.NURSE:
                    GUIController.machineState = GUIController.NURSEMAIN;
                    NurseMain nurseMain = new NurseMain();
                    nurseMain.NurseMainVisible();
                    break;
                default:
                    GUIController.user = null;
                    GUIController.machineState = GUIController.LAUNCH;
                    JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
            this.dispose();
        }
        if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWHISTORY ||
                GUIController.machineState == GUIController.PATIENTHISTORY)
        {
            updateFormFields(GUIController.visitList);
        }
    }
    
    private void updateFormFields(LinkedVisitData data)
    {
        patientID.setText(GUIController.targetlist1.getID());
        firstname.setText(GUIController.targetlist1.getID());
        lastname.setText(GUIController.targetlist1.getID());        
        
        GUIController.information = DatabaseManager.getPatientInformation(GUIController.targetlist1.getID());
        if(GUIController.information == null)
        {    
            if(GUIController.machineState == GUIController.DOCTORCREATEPATIENTDATA
                    || GUIController.machineState == GUIController.NURSECREATEPATIENTDATA)
            {
                doctorIDField.setText("");
                doctorIDField.setEditable(true);
                genderField.setText("");
                genderField.setEditable(true);
                addrField.setText("");
                addrField.setEditable(true);
                contactField.setText("");
                contactField.setEditable(true);
                heightField.setText("");
                heightField.setEditable(true);
                bloodField.setText("");
                bloodField.setEditable(true);
                insurField.setText("");
                insurField.setEditable(true);
                allergyArea.setText("");
                allergyArea.setEditable(true);
                prescriptArea.setText("");
                prescriptArea.setEditable(true);
                conditionArea.setText("");
                conditionArea.setEditable(true);
            }
            else
            {
                GUIController.targetlist1 = null;
                GUIController.targetlist2 = null;
                GUIController.visitList = null;
                switch(GUIController.userType)
                {
                    case GUIController.ADMIN:
                        GUIController.machineState = GUIController.ADMINMAIN;
                        AdminMain adminMain = new AdminMain();
                        adminMain.AdminMainVisible();
                        break;
                    case GUIController.DOCTOR:
                        GUIController.machineState = GUIController.DOCTORMAIN;
                        DoctorMain doctorMain = new DoctorMain();
                        doctorMain.DoctorMainVisible();
                        break;
                    case GUIController.NURSE:
                        GUIController.machineState = GUIController.NURSEMAIN;
                        NurseMain nurseMain = new NurseMain();
                        nurseMain.NurseMainVisible();
                        break;
                    default:
                        GUIController.user = null;
                        GUIController.machineState = GUIController.LAUNCH;
                        JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                        break;
                }
                this.dispose();
            }
        }
        else
        {
            doctorIDField.setText(GUIController.information.getDoctorID());
            genderField.setText(String.valueOf(GUIController.information.getGender()));
            genderField.setEditable(rootPaneCheckingEnabled);
            addrField.setText(GUIController.information.getAddress());
            contactField.setText(GUIController.information.getPhoneNumber());
            heightField.setText(String.valueOf(GUIController.information.getHeight()));
            bloodField.setText(GUIController.information.getBloodType());
            insurField.setText(GUIController.information.getInsurance());
            allergyArea.setText(GUIController.information.getAllergies());
            prescriptArea.setText(GUIController.information.getPrescriptions());
            conditionArea.setText(GUIController.information.getConditionsAndNotes());
        }
        if(data != null)
        {            
            if(GUIController.machineState == GUIController.DOCTORCREATEPATIENTDATA
                    || GUIController.machineState == GUIController.NURSECREATEPATIENTDATA
                    || GUIController.information == null)
            {
                GUIController.targetlist1 = null;
                GUIController.targetlist2 = null;
                GUIController.visitList = null;
                switch(GUIController.userType)
                {
                    case GUIController.ADMIN:
                        GUIController.machineState = GUIController.ADMINMAIN;
                        AdminMain adminMain = new AdminMain();
                        adminMain.AdminMainVisible();
                        break;
                    case GUIController.DOCTOR:
                        GUIController.machineState = GUIController.DOCTORMAIN;
                        DoctorMain doctorMain = new DoctorMain();
                        doctorMain.DoctorMainVisible();
                        break;
                    case GUIController.NURSE:
                        GUIController.machineState = GUIController.NURSEMAIN;
                        NurseMain nurseMain = new NurseMain();
                        nurseMain.NurseMainVisible();
                        break;
                    default:
                        GUIController.user = null;
                        GUIController.machineState = GUIController.LAUNCH;
                        JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                        break;
                }
                this.dispose();
            }
            else
            {
                visitDate.setText(data.getDate());
                tempField.setText(String.valueOf(data.getTemperature()));
                preasureField.setText(String.valueOf(data.getBloodPreasure()));
                weightField.setText(String.valueOf(data.getWeight()));
                complainArea.setText(data.getComplaints());
                observeArea.setText(data.getDoctorNotes());
                mediArea.setText(data.getMedication());
                actionsField.setText(data.getDoctorActions());
                viewRecordReadOnly();
            }
        }
        else
        {
            switch(GUIController.userType)
            {
                case GUIController.NURSE:
                    nurseAccessReadOnly();
                    break;
                case GUIController.PATIENT:
                    patientAccessReadOnly();
                    break;
                case GUIController.DOCTOR:
                    break;
                default:
                    GUIController.targetlist1 = null;
                    GUIController.targetlist2 = null;
                    GUIController.visitList = null;
                    switch(GUIController.userType)
                    {
                        case GUIController.ADMIN:
                            GUIController.machineState = GUIController.ADMINMAIN;
                            AdminMain adminMain = new AdminMain();
                            adminMain.AdminMainVisible();
                            break;
                        default:
                            GUIController.user = null;
                            GUIController.machineState = GUIController.LAUNCH;
                            JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                            break;
                    }
                    this.dispose();
                    break;
            }
        }

    }
    
    class ShowTime extends TimerTask{
        @Override
        public void run(){
            datetime.setText(sdf.format(new Date()));
            repaint();
        }
    }
    
    public void PatientInfoVisible(){
        this.setVisible(true);		
    }
    
    public void viewRecordReadOnly(){
        addrField.setEditable(false);
        genderField.setEditable(false);
        heightField.setEditable(false);
        weightField.setEditable(false);
        bloodField.setEditable(false);
        insurField.setEditable(false);
        allergyArea.setEditable(false);
        mediArea.setEditable(false);
        confirmButton.setEnabled(false);
        tempField.setEditable(false);
        preasureField.setEditable(false);
        complainArea.setEditable(false);
        observeArea.setEditable(false);
        prescriptArea.setEditable(false);
        setPermissionButton.setEnabled(false);
        if(GUIController.userType == GUIController.PATIENT)
        {
            markInvalidButton.setEnabled(false);
        }
        confirmButton2.setEnabled(false);
    }
    
    public void patientAccessReadOnly(){
        addrField.setEditable(false);
        genderField.setEditable(false);
        heightField.setEditable(false);
        weightField.setEditable(false);
        bloodField.setEditable(false);
        insurField.setEditable(false);
        allergyArea.setEditable(false);
        mediArea.setEditable(false);
        confirmButton.setEnabled(false);
        complainArea.setEditable(false);
        observeArea.setEditable(false);
        prescriptArea.setEditable(false);
        setPermissionButton.setEnabled(false);
        markInvalidButton.setEnabled(false);
    }
    
    public void nurseAccessReadOnly(){
        complainArea.setEditable(false);
        observeArea.setEditable(false);
        prescriptArea.setEditable(false);
        setPermissionButton.setEnabled(false);
        markInvalidButton.setEnabled(false);
        prevButton.setEnabled(false);
        backButton.setEnabled(false);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        completeDialog = new javax.swing.JDialog();
        completePanel = new javax.swing.JPanel();
        completeButton = new javax.swing.JButton();
        completeLabel = new javax.swing.JLabel();
        setPermissionDialog = new javax.swing.JDialog();
        setPermissionPanel = new javax.swing.JPanel();
        patientLabel2 = new javax.swing.JLabel();
        patientName = new javax.swing.JLabel();
        doctorLabel2 = new javax.swing.JLabel();
        doctorName = new javax.swing.JLabel();
        tempCheck = new javax.swing.JCheckBox();
        sugarCheck = new javax.swing.JCheckBox();
        weightCheck = new javax.swing.JCheckBox();
        cancelButton3 = new javax.swing.JButton();
        grantButton = new javax.swing.JButton();
        tabbedPane = new javax.swing.JTabbedPane();
        basicPanel = new javax.swing.JPanel();
        lastLabel = new javax.swing.JLabel();
        lastname = new javax.swing.JLabel();
        firstLabel = new javax.swing.JLabel();
        firstname = new javax.swing.JLabel();
        genderLabel = new javax.swing.JLabel();
        addrLabel = new javax.swing.JLabel();
        contactLabel = new javax.swing.JLabel();
        genderField = new javax.swing.JTextField();
        addrField = new javax.swing.JTextField();
        heightLabel = new javax.swing.JLabel();
        bloodLabel = new javax.swing.JLabel();
        heightField = new javax.swing.JTextField();
        bloodField = new javax.swing.JTextField();
        insurLabel = new javax.swing.JLabel();
        insurField = new javax.swing.JTextField();
        allergyLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        allergyArea = new javax.swing.JTextArea();
        confirmButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        contactField = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        prescriptArea = new javax.swing.JTextArea();
        prescriptLabel = new javax.swing.JLabel();
        doctorIDField = new javax.swing.JTextField();
        doctorIDLable = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        conditionArea = new javax.swing.JTextArea();
        conditionLable = new javax.swing.JLabel();
        healthPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        mediArea = new javax.swing.JTextArea();
        mediLabel = new javax.swing.JLabel();
        visitLabel = new javax.swing.JLabel();
        visitDate = new javax.swing.JLabel();
        tempLabel = new javax.swing.JLabel();
        preasureLabel = new javax.swing.JLabel();
        tempField = new javax.swing.JTextField();
        complainLabel = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        complainArea = new javax.swing.JTextArea();
        observeLabel = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        observeArea = new javax.swing.JTextArea();
        prevButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        markInvalidButton = new javax.swing.JButton();
        confirmButton2 = new javax.swing.JButton();
        cancelButton2 = new javax.swing.JButton();
        preasureField = new javax.swing.JTextField();
        setPermissionButton = new javax.swing.JButton();
        weightField = new javax.swing.JTextField();
        weightLabel = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        actionsField = new javax.swing.JTextArea();
        actionsLable = new javax.swing.JLabel();
        patientIDLabel = new javax.swing.JLabel();
        patientID = new javax.swing.JLabel();
        datetime = new javax.swing.JLabel();

        completeDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        completeDialog.setTitle("Attention");
        completeDialog.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        completeDialog.setIconImage(null);
        completeDialog.setName("completeDialog"); // NOI18N
        completeDialog.getContentPane().setLayout(null);

        completePanel.setMaximumSize(new java.awt.Dimension(285, 190));
        completePanel.setPreferredSize(new java.awt.Dimension(285, 190));
        completePanel.setLayout(null);

        completeButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        completeButton.setText("Confirm");
        completeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeButtonActionPerformed(evt);
            }
        });
        completePanel.add(completeButton);
        completeButton.setBounds(90, 100, 100, 30);

        completeLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        completePanel.add(completeLabel);
        completeLabel.setBounds(60, 40, 160, 30);

        completeDialog.getContentPane().add(completePanel);
        completePanel.setBounds(0, 0, 285, 190);

        setPermissionDialog.setTitle("Set Permission");
        setPermissionDialog.getContentPane().setLayout(null);

        setPermissionPanel.setLayout(null);

        patientLabel2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientLabel2.setText("Patient:");
        setPermissionPanel.add(patientLabel2);
        patientLabel2.setBounds(60, 30, 50, 18);

        patientName.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientName.setText("PatientName");
        setPermissionPanel.add(patientName);
        patientName.setBounds(120, 30, 80, 18);

        doctorLabel2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        doctorLabel2.setText("Doctor:");
        setPermissionPanel.add(doctorLabel2);
        doctorLabel2.setBounds(260, 30, 50, 18);

        doctorName.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        doctorName.setText("DoctorName");
        setPermissionPanel.add(doctorName);
        doctorName.setBounds(310, 30, 70, 18);

        tempCheck.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        tempCheck.setText("Temperature");
        setPermissionPanel.add(tempCheck);
        tempCheck.setBounds(60, 70, 110, 27);

        sugarCheck.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        sugarCheck.setText("Blood  Preasure");
        sugarCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sugarCheckActionPerformed(evt);
            }
        });
        setPermissionPanel.add(sugarCheck);
        sugarCheck.setBounds(60, 110, 120, 27);

        weightCheck.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        weightCheck.setText("Weight");
        setPermissionPanel.add(weightCheck);
        weightCheck.setBounds(260, 110, 70, 27);

        cancelButton3.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cancelButton3.setText("Cancel");
        cancelButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton3ActionPerformed(evt);
            }
        });
        setPermissionPanel.add(cancelButton3);
        cancelButton3.setBounds(130, 210, 130, 30);

        grantButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        grantButton.setText("Grant Permission");
        grantButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grantButtonActionPerformed(evt);
            }
        });
        setPermissionPanel.add(grantButton);
        grantButton.setBounds(130, 160, 130, 30);

        setPermissionDialog.getContentPane().add(setPermissionPanel);
        setPermissionPanel.setBounds(0, 0, 400, 300);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Visit Record");
        setMinimumSize(new java.awt.Dimension(450, 650));
        setResizable(false);
        getContentPane().setLayout(null);

        tabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tabbedPaneMouseReleased(evt);
            }
        });

        basicPanel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.setLayout(null);

        lastLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        lastLabel.setText("Last Name");
        basicPanel.add(lastLabel);
        lastLabel.setBounds(20, 10, 75, 20);

        lastname.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        lastname.setText("lastname");
        basicPanel.add(lastname);
        lastname.setBounds(95, 10, 100, 20);

        firstLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        firstLabel.setText("First Name ");
        basicPanel.add(firstLabel);
        firstLabel.setBounds(210, 10, 75, 20);

        firstname.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        firstname.setText("firstname");
        basicPanel.add(firstname);
        firstname.setBounds(290, 10, 100, 20);

        genderLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        genderLabel.setText("Gender ");
        basicPanel.add(genderLabel);
        genderLabel.setBounds(230, 50, 50, 20);

        addrLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        addrLabel.setText("Address");
        basicPanel.add(addrLabel);
        addrLabel.setBounds(20, 95, 75, 20);

        contactLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        contactLabel.setText("Contact");
        basicPanel.add(contactLabel);
        contactLabel.setBounds(230, 95, 75, 20);

        genderField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        genderField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderFieldActionPerformed(evt);
            }
        });
        basicPanel.add(genderField);
        genderField.setBounds(280, 50, 40, 30);

        addrField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(addrField);
        addrField.setBounds(70, 90, 140, 30);

        heightLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        heightLabel.setText("Height(cm)");
        basicPanel.add(heightLabel);
        heightLabel.setBounds(20, 155, 75, 20);

        bloodLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        bloodLabel.setText("Blood Type");
        basicPanel.add(bloodLabel);
        bloodLabel.setBounds(300, 155, 75, 20);

        heightField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(heightField);
        heightField.setBounds(90, 150, 45, 30);

        bloodField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(bloodField);
        bloodField.setBounds(370, 150, 40, 30);

        insurLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        insurLabel.setText("Insurance");
        basicPanel.add(insurLabel);
        insurLabel.setBounds(20, 215, 75, 20);

        insurField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(insurField);
        insurField.setBounds(90, 210, 180, 30);

        allergyLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        allergyLabel.setText("Allergy");
        basicPanel.add(allergyLabel);
        allergyLabel.setBounds(20, 280, 75, 20);

        allergyArea.setColumns(20);
        allergyArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        allergyArea.setRows(5);
        jScrollPane1.setViewportView(allergyArea);

        basicPanel.add(jScrollPane1);
        jScrollPane1.setBounds(90, 280, 320, 60);

        confirmButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        confirmButton.setText("Confirm");
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });
        basicPanel.add(confirmButton);
        confirmButton.setBounds(190, 500, 100, 30);

        cancelButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        basicPanel.add(cancelButton);
        cancelButton.setBounds(310, 500, 100, 30);

        contactField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(contactField);
        contactField.setBounds(280, 90, 130, 30);

        prescriptArea.setColumns(20);
        prescriptArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        prescriptArea.setRows(5);
        jScrollPane5.setViewportView(prescriptArea);

        basicPanel.add(jScrollPane5);
        jScrollPane5.setBounds(90, 350, 320, 60);

        prescriptLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        prescriptLabel.setText("Prescription");
        basicPanel.add(prescriptLabel);
        prescriptLabel.setBounds(20, 350, 80, 20);

        doctorIDField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        basicPanel.add(doctorIDField);
        doctorIDField.setBounds(70, 50, 140, 30);

        doctorIDLable.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        doctorIDLable.setText("Dr ID");
        basicPanel.add(doctorIDLable);
        doctorIDLable.setBounds(20, 50, 75, 20);

        conditionArea.setColumns(20);
        conditionArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        conditionArea.setRows(5);
        jScrollPane6.setViewportView(conditionArea);

        basicPanel.add(jScrollPane6);
        jScrollPane6.setBounds(90, 420, 320, 60);

        conditionLable.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        conditionLable.setText("Conditions");
        basicPanel.add(conditionLable);
        conditionLable.setBounds(20, 420, 80, 30);

        tabbedPane.addTab("Basic", basicPanel);

        healthPanel.setLayout(null);

        mediArea.setColumns(20);
        mediArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        mediArea.setRows(5);
        jScrollPane2.setViewportView(mediArea);

        healthPanel.add(jScrollPane2);
        jScrollPane2.setBounds(110, 270, 310, 70);

        mediLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        mediLabel.setText("Medication");
        healthPanel.add(mediLabel);
        mediLabel.setBounds(20, 270, 75, 20);

        visitLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        visitLabel.setText("Visit Date");
        healthPanel.add(visitLabel);
        visitLabel.setBounds(20, 10, 70, 20);

        visitDate.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        visitDate.setText("MM-DD-YYYY");
        healthPanel.add(visitDate);
        visitDate.setBounds(90, 10, 90, 18);

        tempLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        tempLabel.setText("Temperature(C)");
        healthPanel.add(tempLabel);
        tempLabel.setBounds(190, 50, 85, 18);

        preasureLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        preasureLabel.setText("Blood Preasure mmHg");
        healthPanel.add(preasureLabel);
        preasureLabel.setBounds(250, 10, 130, 20);

        tempField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        healthPanel.add(tempField);
        tempField.setBounds(280, 50, 30, 30);

        complainLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        complainLabel.setText("Complain");
        healthPanel.add(complainLabel);
        complainLabel.setBounds(20, 85, 70, 20);

        complainArea.setColumns(20);
        complainArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        complainArea.setRows(5);
        jScrollPane3.setViewportView(complainArea);

        healthPanel.add(jScrollPane3);
        jScrollPane3.setBounds(110, 90, 310, 70);

        observeLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        observeLabel.setText("Observation");
        healthPanel.add(observeLabel);
        observeLabel.setBounds(20, 170, 70, 20);

        observeArea.setColumns(20);
        observeArea.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        observeArea.setRows(5);
        jScrollPane4.setViewportView(observeArea);

        healthPanel.add(jScrollPane4);
        jScrollPane4.setBounds(110, 180, 310, 70);

        prevButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        prevButton.setText("<< Previous");
        prevButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevButtonActionPerformed(evt);
            }
        });
        healthPanel.add(prevButton);
        prevButton.setBounds(20, 450, 100, 30);

        backButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        backButton.setText("Back >>");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        healthPanel.add(backButton);
        backButton.setBounds(20, 500, 100, 30);

        markInvalidButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        markInvalidButton.setText("Mark Invalid");
        markInvalidButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                markInvalidButtonActionPerformed(evt);
            }
        });
        healthPanel.add(markInvalidButton);
        markInvalidButton.setBounds(300, 450, 120, 30);

        confirmButton2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        confirmButton2.setText("Confirm");
        confirmButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButton2ActionPerformed(evt);
            }
        });
        healthPanel.add(confirmButton2);
        confirmButton2.setBounds(160, 500, 120, 30);

        cancelButton2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cancelButton2.setText("Cancel");
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });
        healthPanel.add(cancelButton2);
        cancelButton2.setBounds(300, 500, 120, 30);

        preasureField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        healthPanel.add(preasureField);
        preasureField.setBounds(390, 10, 30, 30);

        setPermissionButton.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        setPermissionButton.setText("Set Permission");
        setPermissionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setPermissionButtonActionPerformed(evt);
            }
        });
        healthPanel.add(setPermissionButton);
        setPermissionButton.setBounds(160, 450, 120, 30);

        weightField.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        healthPanel.add(weightField);
        weightField.setBounds(390, 50, 30, 30);

        weightLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        weightLabel.setText("Weight(kg)");
        healthPanel.add(weightLabel);
        weightLabel.setBounds(320, 50, 75, 20);

        actionsField.setColumns(20);
        actionsField.setFont(new java.awt.Font("Comic Sans MS", 0, 10)); // NOI18N
        actionsField.setRows(5);
        jScrollPane7.setViewportView(actionsField);

        healthPanel.add(jScrollPane7);
        jScrollPane7.setBounds(110, 360, 310, 70);

        actionsLable.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        actionsLable.setText("Actions");
        healthPanel.add(actionsLable);
        actionsLable.setBounds(20, 360, 75, 20);

        tabbedPane.addTab("Health", healthPanel);

        getContentPane().add(tabbedPane);
        tabbedPane.setBounds(0, 30, 450, 620);

        patientIDLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientIDLabel.setText("Patient ID:");
        patientIDLabel.setToolTipText("");
        getContentPane().add(patientIDLabel);
        patientIDLabel.setBounds(30, 10, 70, 18);

        patientID.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        patientID.setText("PatientID");
        getContentPane().add(patientID);
        patientID.setBounds(100, 10, 100, 18);

        datetime.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        datetime.setText("MM-DD-YYYY HH:MM:SS");
        getContentPane().add(datetime);
        datetime.setBounds(240, 10, 160, 18);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
//        int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//        int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        if(GUIController.information != null)
        {
            if(DatabaseManager.find(doctorIDField.getText(),null,null,GUIController.DOCTOR) != null)
            {
                DatabaseManager.inputPatientInfo(GUIController.targetlist1.getID(),
                        genderField.getText().charAt(0),
                        Float.parseFloat(heightField.getText()),
                        allergyArea.getText(),
                        prescriptArea.getText(),
                        conditionArea.getText(),
                        bloodField.getText(),
                        insurField.getText(),
                        addrField.getText(),
                        contactField.getText(),
                        doctorIDField.getText(),
                        false, false, false);
            }
            else
            {
                 JOptionPane.showMessageDialog(null, "Please enter a doctor!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else
        {
            DatabaseManager.updateAddress(GUIController.targetlist1.getID(), addrField.getText());
            DatabaseManager.updateAllergies(GUIController.targetlist1.getID(), allergyArea.getText());
            DatabaseManager.updateConditionsAndNotes(GUIController.targetlist1.getID(), conditionArea.getText());
            if(DatabaseManager.find(doctorIDField.getText(),null,null,GUIController.DOCTOR) != null)
            {
                DatabaseManager.updateDoctor(GUIController.targetlist1.getID(), doctorIDField.getText());
            }
            else
            {
                 JOptionPane.showMessageDialog(null, "Please enter a doctor!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
            }
            DatabaseManager.updateInsurance(GUIController.targetlist1.getID(), insurField.getText());
            DatabaseManager.updatePrescriptions(GUIController.targetlist1.getID(), prescriptArea.getText());
        }
        completeDialog.setSize(285, 190);
        completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
        completeLabel.setText("Database update complete.");
        completeDialog.setVisible(true);
    }//GEN-LAST:event_confirmButtonActionPerformed

    private void completeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completeButtonActionPerformed
        completeDialog.dispose();
    }//GEN-LAST:event_completeButtonActionPerformed

    private void confirmButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButton2ActionPerformed
//        int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//        int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        DatabaseManager.inputVisitData(GUIController.targetlist1.getID(),
                Float.parseFloat(preasureField.getText()),
                Float.parseFloat(tempField.getText()),
                Float.parseFloat(weightField.getText()),
                mediArea.getText(),
                complainArea.getText(),
                observeArea.getText(),
                actionsField.getText());
        completeDialog.setSize(285, 190);
        completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
        completeLabel.setText("Database update complete.");
        completeDialog.setVisible(true);
    }//GEN-LAST:event_confirmButton2ActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        GUIController.targetlist1 = null;
        GUIController.targetlist2 = null;
        GUIController.visitList = null;
        GUIController.information = null;
        switch(GUIController.userType)
        {
            case GUIController.ADMIN:
                GUIController.machineState = GUIController.ADMINMAIN;
                AdminMain adminMain = new AdminMain();
                adminMain.AdminMainVisible();
                break;
            case GUIController.DOCTOR:
                GUIController.machineState = GUIController.DOCTORMAIN;
                DoctorMain doctorMain = new DoctorMain();
                doctorMain.DoctorMainVisible();
                break;
            case GUIController.NURSE:
                GUIController.machineState = GUIController.NURSEMAIN;
                NurseMain nurseMain = new NurseMain();
                nurseMain.NurseMainVisible();
                break;
            default:
                GUIController.user = null;
                GUIController.machineState = GUIController.LAUNCH;
                JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
        this.dispose();
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
        GUIController.targetlist1 = null;
        GUIController.targetlist2 = null;
        GUIController.visitList = null;
        GUIController.information = null;
        switch(GUIController.userType)
        {
            case GUIController.ADMIN:
                GUIController.machineState = GUIController.ADMINMAIN;
                AdminMain adminMain = new AdminMain();
                adminMain.AdminMainVisible();
                break;
            case GUIController.DOCTOR:
                GUIController.machineState = GUIController.DOCTORMAIN;
                DoctorMain doctorMain = new DoctorMain();
                doctorMain.DoctorMainVisible();
                break;
            case GUIController.NURSE:
                GUIController.machineState = GUIController.NURSEMAIN;
                NurseMain nurseMain = new NurseMain();
                nurseMain.NurseMainVisible();
                break;
            default:
                GUIController.user = null;
                GUIController.machineState = GUIController.LAUNCH;
                JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
        this.dispose();
    }//GEN-LAST:event_cancelButton2ActionPerformed

    private void grantButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grantButtonActionPerformed
        if(tempCheck.isSelected()||sugarCheck.isSelected()||weightCheck.isSelected()){
            DatabaseManager.updateSubmissionPermissions(GUIController.targetlist1.getID(), sugarCheck.isSelected(), tempCheck.isSelected(), weightCheck.isSelected());
            completeDialog.setSize(285, 190);
            completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
            completeLabel.setText("Permission is granted.");
            completeDialog.setVisible(true);
            setPermissionDialog.setVisible(false);
        }
        else{
            JOptionPane.showMessageDialog(null, "Please check at least one indicator!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_grantButtonActionPerformed

    private void cancelButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton3ActionPerformed
        setPermissionDialog.dispose();
    }//GEN-LAST:event_cancelButton3ActionPerformed

    private void markInvalidButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_markInvalidButtonActionPerformed
        if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWHISTORY)
        {
            DatabaseManager.markVisitValidity(GUIController.targetlist1.getID(), GUIController.visitList.getDate(), false);
            completeDialog.setSize(285, 190);
            completeDialog.setLocation((screenWidth - completeDialog.getSize().width) / 2,(screenHeight - completeDialog.getSize().height) / 2);            
            completeLabel.setText("Marking invalid complete.");
            completeDialog.setVisible(true);
        }
    }//GEN-LAST:event_markInvalidButtonActionPerformed

    private void setPermissionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setPermissionButtonActionPerformed
        sugarCheck.setSelected(GUIController.information.getBloodPermissions());
        tempCheck.setSelected(GUIController.information.getTemperaturePermssions());
        weightCheck.setSelected(GUIController.information.getWeightPermissions());
        setPermissionDialog.setSize(450, 300);
        setPermissionDialog.setLocation((screenWidth - setPermissionDialog.getSize().width) / 2,(screenHeight - setPermissionDialog.getSize().height) / 2);            
        setPermissionDialog.setVisible(true);
    }//GEN-LAST:event_setPermissionButtonActionPerformed

    private void tabbedPaneMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabbedPaneMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tabbedPaneMouseReleased

    private void genderFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderFieldActionPerformed

    private void sugarCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sugarCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sugarCheckActionPerformed

    private void prevButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevButtonActionPerformed
        if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWNEW ||
                GUIController.machineState == GUIController.PATIENTUPDATE)
        {
            GUIController.visitList = DatabaseManager.getVisitData(GUIController.targetlist1.getID());
            GUIController.machineState = GUIController.DOCTORHEALTHVIEWHISTORY;
            updateFormFields(GUIController.visitList);
        }
        else if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWHISTORY ||
                GUIController.machineState == GUIController.PATIENTHISTORY)
        {
            if(GUIController.visitList == null)
            {
                GUIController.targetlist1 = null;
                GUIController.targetlist2 = null;
                GUIController.visitList = null;
                GUIController.information = null;
                switch(GUIController.userType)
                {
                    case GUIController.ADMIN:
                        GUIController.machineState = GUIController.ADMINMAIN;
                        AdminMain adminMain = new AdminMain();
                        adminMain.AdminMainVisible();
                        break;
                    case GUIController.DOCTOR:
                        GUIController.machineState = GUIController.DOCTORMAIN;
                        DoctorMain doctorMain = new DoctorMain();
                        doctorMain.DoctorMainVisible();
                        break;
                    case GUIController.NURSE:
                        GUIController.machineState = GUIController.NURSEMAIN;
                        NurseMain nurseMain = new NurseMain();
                        nurseMain.NurseMainVisible();
                        break;
                    default:
                        GUIController.user = null;
                        GUIController.machineState = GUIController.LAUNCH;
                        JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                        break;
                }
                this.dispose();
            }
            else if(GUIController.visitList.getPrevious() == null)
            {
                updateFormFields(GUIController.visitList);
            }
            else
            {
                GUIController.visitList = GUIController.visitList.getPrevious();
                updateFormFields(GUIController.visitList);
            }
        }
        else
        {
            GUIController.targetlist1 = null;
            GUIController.targetlist2 = null;
            GUIController.visitList = null;
            GUIController.information = null;
            switch(GUIController.userType)
            {
                case GUIController.ADMIN:
                    GUIController.machineState = GUIController.ADMINMAIN;
                    AdminMain adminMain = new AdminMain();
                    adminMain.AdminMainVisible();
                    break;
                case GUIController.DOCTOR:
                    GUIController.machineState = GUIController.DOCTORMAIN;
                    DoctorMain doctorMain = new DoctorMain();
                    doctorMain.DoctorMainVisible();
                    break;
                case GUIController.NURSE:
                    GUIController.machineState = GUIController.NURSEMAIN;
                    NurseMain nurseMain = new NurseMain();
                    nurseMain.NurseMainVisible();
                    break;
                default:
                    GUIController.user = null;
                    GUIController.machineState = GUIController.LAUNCH;
                    JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
            this.dispose();
        }
    }//GEN-LAST:event_prevButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWNEW ||
                GUIController.machineState == GUIController.PATIENTUPDATE)
        {
        }
        else if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWHISTORY ||
                GUIController.machineState == GUIController.PATIENTHISTORY)
        {
            if(GUIController.visitList == null)
            {
                GUIController.targetlist1 = null;
                GUIController.targetlist2 = null;
                GUIController.visitList = null;
                GUIController.information = null;
                switch(GUIController.userType)
                {
                    case GUIController.ADMIN:
                        GUIController.machineState = GUIController.ADMINMAIN;
                        AdminMain adminMain = new AdminMain();
                        adminMain.AdminMainVisible();
                        break;
                    case GUIController.DOCTOR:
                        GUIController.machineState = GUIController.DOCTORMAIN;
                        DoctorMain doctorMain = new DoctorMain();
                        doctorMain.DoctorMainVisible();
                        break;
                    case GUIController.NURSE:
                        GUIController.machineState = GUIController.NURSEMAIN;
                        NurseMain nurseMain = new NurseMain();
                        nurseMain.NurseMainVisible();
                        break;
                    default:
                        GUIController.user = null;
                        GUIController.machineState = GUIController.LAUNCH;
                        JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                        break;
                }
                this.dispose();
            }
            else if(GUIController.visitList.getNext() == null)
            {
                if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWNEW ||
                        GUIController.machineState == GUIController.PATIENTUPDATE)
                {
                    GUIController.visitList = DatabaseManager.getVisitData(GUIController.targetlist1.getID());
                    GUIController.machineState = GUIController.DOCTORHEALTHVIEWHISTORY;
                    updateFormFields(GUIController.visitList);
                }
                else if(GUIController.machineState == GUIController.DOCTORHEALTHVIEWHISTORY ||
                        GUIController.machineState == GUIController.PATIENTHISTORY)
                {
                    if(GUIController.visitList == null)
                    {
                        GUIController.targetlist1 = null;
                        GUIController.targetlist2 = null;
                        GUIController.visitList = null;
                        GUIController.information = null;
                        switch(GUIController.userType)
                        {
                            case GUIController.ADMIN:
                                GUIController.machineState = GUIController.ADMINMAIN;
                                AdminMain adminMain = new AdminMain();
                                adminMain.AdminMainVisible();
                                break;
                            case GUIController.DOCTOR:
                                GUIController.machineState = GUIController.DOCTORMAIN;
                                DoctorMain doctorMain = new DoctorMain();
                                doctorMain.DoctorMainVisible();
                                break;
                            case GUIController.NURSE:
                                GUIController.machineState = GUIController.NURSEMAIN;
                                NurseMain nurseMain = new NurseMain();
                                nurseMain.NurseMainVisible();
                                break;
                            case GUIController.PATIENT:
                                GUIController.machineState = GUIController.PATIENTMAIN;
                                PatientMain patientMain = new PatientMain();
                                patientMain.PatientMainVisible();
                                break;
                            default:
                                GUIController.user = null;
                                GUIController.machineState = GUIController.LAUNCH;
                                JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                                break;
                        }
                        this.dispose();
                    }
                    else if(GUIController.visitList.getPrevious() == null)
                    {
                        updateFormFields(GUIController.visitList);
                    }
                    else
                    {
                        GUIController.visitList = GUIController.visitList.getPrevious();
                        updateFormFields(GUIController.visitList);
                    }
                }
                else
                {
                    switch(GUIController.userType)
                    {
                        case GUIController.ADMIN:
                            GUIController.targetlist1 = null;
                            GUIController.targetlist2 = null;
                            GUIController.visitList = null;
                            GUIController.information = null;
                            GUIController.machineState = GUIController.ADMINMAIN;
                            AdminMain adminMain = new AdminMain();
                            adminMain.AdminMainVisible();
                            this.dispose();
                            break;
                        case GUIController.DOCTOR:
                            GUIController.machineState = GUIController.DOCTORHEALTHVIEWNEW;
                            break;
                        case GUIController.PATIENT:
                            GUIController.machineState = GUIController.PATIENTUPDATE;
                            break;
                        case GUIController.NURSE:
                            GUIController.targetlist1 = null;
                            GUIController.targetlist2 = null;
                            GUIController.visitList = null;
                            GUIController.information = null;
                            GUIController.machineState = GUIController.NURSEMAIN;
                            NurseMain nurseMain = new NurseMain();
                            nurseMain.NurseMainVisible();
                            this.dispose();
                            break;
                        default:
                            GUIController.user = null;
                            GUIController.machineState = GUIController.LAUNCH;
                            JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                            this.dispose();
                            break;
                    }
                    updateFormFields(null);

                }
                
            }
            else
            {
                GUIController.visitList = GUIController.visitList.getNext();
                updateFormFields(GUIController.visitList);
            }
        }
        else
        {
            GUIController.targetlist1 = null;
            GUIController.targetlist2 = null;
            GUIController.visitList = null;
            GUIController.information = null;
            switch(GUIController.userType)
            {
                case GUIController.ADMIN:
                    GUIController.machineState = GUIController.ADMINMAIN;
                    AdminMain adminMain = new AdminMain();
                    adminMain.AdminMainVisible();
                    break;
                case GUIController.DOCTOR:
                    GUIController.machineState = GUIController.DOCTORMAIN;
                    DoctorMain doctorMain = new DoctorMain();
                    doctorMain.DoctorMainVisible();
                    break;
                case GUIController.NURSE:
                    GUIController.machineState = GUIController.NURSEMAIN;
                    NurseMain nurseMain = new NurseMain();
                    nurseMain.NurseMainVisible();
                    break;
                default:
                    GUIController.user = null;
                    GUIController.machineState = GUIController.LAUNCH;
                    JOptionPane.showMessageDialog(null, "Invalid user type!", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
            this.dispose();
        }
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea actionsField;
    private javax.swing.JLabel actionsLable;
    private javax.swing.JTextField addrField;
    private javax.swing.JLabel addrLabel;
    private javax.swing.JTextArea allergyArea;
    private javax.swing.JLabel allergyLabel;
    private javax.swing.JButton backButton;
    private javax.swing.JPanel basicPanel;
    private javax.swing.JTextField bloodField;
    private javax.swing.JLabel bloodLabel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JButton cancelButton3;
    private javax.swing.JTextArea complainArea;
    private javax.swing.JLabel complainLabel;
    private javax.swing.JButton completeButton;
    private javax.swing.JDialog completeDialog;
    private javax.swing.JLabel completeLabel;
    private javax.swing.JPanel completePanel;
    private javax.swing.JTextArea conditionArea;
    private javax.swing.JLabel conditionLable;
    private javax.swing.JButton confirmButton;
    private javax.swing.JButton confirmButton2;
    private javax.swing.JTextField contactField;
    private javax.swing.JLabel contactLabel;
    private javax.swing.JLabel datetime;
    private javax.swing.JTextField doctorIDField;
    private javax.swing.JLabel doctorIDLable;
    private javax.swing.JLabel doctorLabel2;
    private javax.swing.JLabel doctorName;
    private javax.swing.JLabel firstLabel;
    private javax.swing.JLabel firstname;
    private javax.swing.JTextField genderField;
    private javax.swing.JLabel genderLabel;
    private javax.swing.JButton grantButton;
    private javax.swing.JPanel healthPanel;
    private javax.swing.JTextField heightField;
    private javax.swing.JLabel heightLabel;
    private javax.swing.JTextField insurField;
    private javax.swing.JLabel insurLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lastLabel;
    private javax.swing.JLabel lastname;
    private javax.swing.JButton markInvalidButton;
    private javax.swing.JTextArea mediArea;
    private javax.swing.JLabel mediLabel;
    private javax.swing.JTextArea observeArea;
    private javax.swing.JLabel observeLabel;
    private javax.swing.JLabel patientID;
    private javax.swing.JLabel patientIDLabel;
    private javax.swing.JLabel patientLabel2;
    private javax.swing.JLabel patientName;
    private javax.swing.JTextField preasureField;
    private javax.swing.JLabel preasureLabel;
    private javax.swing.JTextArea prescriptArea;
    private javax.swing.JLabel prescriptLabel;
    private javax.swing.JButton prevButton;
    private javax.swing.JButton setPermissionButton;
    private javax.swing.JDialog setPermissionDialog;
    private javax.swing.JPanel setPermissionPanel;
    private javax.swing.JCheckBox sugarCheck;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JCheckBox tempCheck;
    private javax.swing.JTextField tempField;
    private javax.swing.JLabel tempLabel;
    private javax.swing.JLabel visitDate;
    private javax.swing.JLabel visitLabel;
    private javax.swing.JCheckBox weightCheck;
    private javax.swing.JTextField weightField;
    private javax.swing.JLabel weightLabel;
    // End of variables declaration//GEN-END:variables
}
