package databasecontrollertest;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin Rederick aka 0tter and Robin Yau 
 */
public class LinkedLoginData {
    private String firstName;
    private String lastName;
    private String id;
    private String password;
    private int userType;
    private Boolean loginAllowed;
    private LinkedLoginData next;
    
    public LinkedLoginData(String fn, String ln, String idNum, String pw, int ut, Boolean la)
    {
        firstName = fn;
        lastName = ln;
        id = idNum;
        password = pw;
        userType = ut;
        loginAllowed = la;
        next = null;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public String getID()
    {
        return id;
    }
    public boolean comparePassword(String passwordEntered)
    {
        return passwordEntered.equals(password);
    }
    private String retrievePassword()
    {
        return password;
    }
    public int getUserType()
    {
        return userType;
    }
    public Boolean getLoginPermission()
    {
        return loginAllowed;
    }
    public void setNext(LinkedLoginData n)
    {
        next = n;
    }
    public LinkedLoginData getNext()
    {
        return next;
    }
}
