package databasecontrollertest;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin Rederick AKA OTTER and Robin Yau
 * tutorial help from http://zetcode.com/db/mysqljava/
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatabaseManager {
    //otter keeps constants for database connection here.
    private static String sqlURL = "jdbc:mysql://localhost:3306/projectBeansDB";
    private static String sqlUser = "root";
    private static String sqlPassword = "Magical0tter";

    public static LinkedLoginData getLoginData(String userID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        LinkedLoginData returnData = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ?");
            pst.setString(1, userID);
            rs = pst.executeQuery();
            if(rs.first())
            {   
                returnData = new LinkedLoginData(rs.getString("firstName"),
                        rs.getString("lastName"), rs.getString("id"), rs.getString("password"),
                        rs.getInt("userType"), rs.getBoolean("loginAllowed"));
            }
            else
            {
                returnData = null;
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static LinkedLoginData find(String userID, String firstName,
            String lastName, int userType)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        LinkedLoginData returnData = null;
        String statement = "SELECT * FROM LoginData";
        int start = statement.length();
        int temp = start;
        if(userID != null && userID.length() > 0)
        {
            if(temp == start)
            {
                statement += " WHERE";
                temp++;
            }
            statement += " id = '" + userID + "'";
        }
        if(firstName != null && firstName.length() > 0)
        {
            if(temp == start)
            {
                statement += " WHERE";
                temp++;
            }
            else if(temp < statement.length())
            {
                temp = statement.length();
                statement += " AND";
            }
            statement += " firstName = '" + firstName + "'";
        }
        if(lastName != null && lastName.length() > 0)
        {
            if(temp == start)
            {
                statement += " WHERE";
                temp++;
            }
            else if(temp < statement.length())
            {
                temp = statement.length();
                statement += " AND";
            }
            statement += " lastName = '" + lastName + "'";
        }
        if(userType > -1)
        {   
            if(temp == start)
            {
                statement += " WHERE";
                temp++;
            }
            else if(temp < statement.length())
            {
                statement += " AND";
            }
            statement += " userType = " + userType;
        }
        statement += " ORDER BY lastName, firstName;";
        System.out.println(statement);
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement(statement);

            rs = pst.executeQuery();
            if(rs.first())
            {   
                returnData = new LinkedLoginData(rs.getString("firstName"),
                        rs.getString("lastName"), rs.getString("id"), rs.getString("password"),
                        rs.getInt("userType"), rs.getBoolean("loginAllowed"));
                LinkedLoginData tracer = returnData;
                while(rs.next())
                {
                    tracer.setNext(new LinkedLoginData(rs.getString("firstName"),
                            rs.getString("lastName"), rs.getString("id"), rs.getString("password"),
                            rs.getInt("userType"), rs.getBoolean("loginAllowed")));
                    tracer = tracer.getNext();
                }
            }
            else
            {
                returnData = null;
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
        
    public static LinkedPatientInformation getPatientInformation(String userID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        LinkedPatientInformation returnData = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM PatientInformation WHERE id = ?");
            pst.setString(1, userID);
            rs = pst.executeQuery();
            if(rs.first())
            {
                returnData = new LinkedPatientInformation(rs.getString("id"),
                        rs.getString("gender").charAt(0), rs.getFloat("height"),
                        rs.getString("allergies"), rs.getString("Prescriptions"),
                        rs.getString("conditionsAndNotes"),
                        rs.getString("bloodType"), rs.getString("insurance"),
                        rs.getString("address"), rs.getString("phoneNumber"),
                        rs.getString("doctorID"),
                        rs.getBoolean("submitBlood"),
                        rs.getBoolean("submitTemperature"),
                        rs.getBoolean("submitWeight"));
                LinkedPatientInformation tracer = returnData;
                while(rs.next())
                {
                    tracer.setNext(new LinkedPatientInformation(rs.getString("id"),
                        rs.getString("gender").charAt(0), rs.getFloat("height"),
                        rs.getString("allergies"), rs.getString("Prescriptions"),
                        rs.getString("conditionsAndNotes"),
                        rs.getString("bloodType"), rs.getString("insurance"),
                        rs.getString("address"), rs.getString("phoneNumber"),
                        rs.getString("doctorID"),
                        rs.getBoolean("submitBlood"),
                        rs.getBoolean("submitTemperature"),
                        rs.getBoolean("submitWeight")));
                    tracer = tracer.getNext();
                }
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static LinkedVisitData getVisitData(String userID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        LinkedVisitData returnData = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM ProfileMerger WHERE newID = ?");
            pst.setString(1, userID);
            rs = pst.executeQuery();
            String visitCall = "(SELECT * FROM VisitData WHERE (id = '" + userID + "'"; 
            if(rs.first())
            {
                do
                {
                    visitCall += " OR id = '" + rs.getString("ammendedID") + "'";
                }while(rs.next());
            }
            visitCall += ")";
            rs.close();
            visitCall += ") ORDER BY date DESC";
            pst = con.prepareStatement(visitCall);
            rs = pst.executeQuery();
            if(rs.first())
                {
                    //Otter builds a linked list of his visits here.
                    returnData = new LinkedVisitData(rs.getString("id"),
                            rs.getString("date"), rs.getFloat("bloodPreasure"),
                            rs.getFloat("temperature"), rs.getFloat("weight"),
                            rs.getString("medication"),
                            rs.getString("complaints"), rs.getString("doctorNotes"),
                            rs.getString("doctorActions"), rs.getBoolean("valid"),
                            null);
                    LinkedVisitData dataTracer = returnData;
                    while(rs.next())
                    {
                        dataTracer.setNext(new LinkedVisitData(rs.getString("id"),
                            rs.getString("date"), rs.getFloat("bloodPreasure"),
                            rs.getFloat("temperature"), rs.getFloat("weight"),
                            rs.getString("medication"),
                            rs.getString("complaints"), rs.getString("doctorNotes"),
                            rs.getString("doctorActions"), rs.getBoolean("valid"),
                            dataTracer));
                        dataTracer = dataTracer.getNext();
                    }
                }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs != null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        return returnData;
        }
    }
    
    public static LinkedNurseAssignment getNurseAssignments(String userID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        LinkedNurseAssignment returnData = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM NurseAssignment WHERE nurseID = ?");
            pst.setString(1, userID);
            rs = pst.executeQuery();
            
            if(rs!= null && rs.first())
            {
                returnData = new LinkedNurseAssignment(rs.getString("nurseID"),
                                                          rs.getString("doctorID"));
                while(rs.next())
                {
                    returnData.setNext(new LinkedNurseAssignment(rs.getString("nurseID"),
                                                          rs.getString("doctorID")));
                }
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs != null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static String inputLoginData(String firstName, String lastName, int userType)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        int attempt = 0;
        String id = firstName + lastName + attempt;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            do
            {
                if(rs != null)
                {
                    rs.close();
                }
                id = id.substring(0, id.length() - String.valueOf(attempt++).length()) + attempt;
                pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ?");
                pst.setString(1, id);
                rs = pst.executeQuery();
            } while(rs != null && rs.first());
            pst = con.prepareStatement("INSERT INTO LoginData SET firstName = ?,"
                    + "lastName = ?, id = ?, password = ?, userType = ?, loginAllowed = True");
            pst.setString(1, firstName);
            pst.setString(2, lastName);
            pst.setString(3, id);
            pst.setString(4, id);
            pst.setInt(5,userType);
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return id;
        }
    }
    
    public static void changeName(String id, String firstName, String lastName)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE LoginData SET firstName = ?, lastName = ?"
                    + " WHERE id = ?");
            pst.setString(3, id);
            pst.setString(1, firstName);
            pst.setString(2, lastName);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void setDefaultPassword(String id)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE LoginData SET password = ?"
                    + " WHERE id = ?");
            pst.setString(1, id);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void setPassword(String id, String password)
    {
                Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE LoginData SET password = ?"
                    + " WHERE id = ?");
            pst.setString(1, password);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void setLoginPermission(String id, boolean permission)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE LoginData SET loginAllowed = ?"
                    + " WHERE id = ?");
            if(permission == true){ pst.setBoolean(1, true);}
            else {pst.setBoolean(1, false);}
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void inputNurseAssignment(String nurseID, String doctorID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("INSERT INTO NurseAssignment SET "
                    + "nurseID = ?," + "doctorID = ?");
            pst.setString(1, nurseID);
            pst.setString(2, doctorID);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void removeNurseAssignment(String nurseID, String doctorID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("DELETE FROM NurseAssignment "
                    + "WHERE(nurseID = ? AND doctorID = ?)");
            pst.setString(1, nurseID);
            pst.setString(2, doctorID);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void inputPatientInfo(String id,char gender, float height,
            String allergies, String prescriptions, String conditionsAndNotes,
            String bloodType, String insurance, String address, String phoneNumber,
            String doctorID, boolean submitBlood, boolean submitTemperature,
            boolean submitWeight)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("INSERT INTO PatientInformation SET id = ?,"
                    + "gender = ?, height = ?, allergies = ?, prescriptions = ?,"
                    + " conditionsAndNotes = ?, bloodType = ?, insurance = ?,"
                    + " address = ?, phoneNumber = ?, doctorID = ?, submitBlood = ?,"
                    + " submitTemperature = ?, submitWeight = ?");
            pst.setString(1,id);
            pst.setString(2, Character.toString(gender));
            pst.setFloat(3, height);
            pst.setString(4, allergies);
            pst.setString(5, prescriptions);
            pst.setString(6, conditionsAndNotes);
            pst.setString(7, bloodType);
            pst.setString(8, insurance);
            pst.setString(9, address);
            pst.setString(10, phoneNumber);
            pst.setString(11, doctorID);
            if(submitBlood){pst.setBoolean(12, true);}
            else{pst.setBoolean(12, false);}
            if(submitTemperature){pst.setBoolean(13, true);}
            else{pst.setBoolean(13, false);}
            if(submitWeight){pst.setBoolean(14,true);}
            else{pst.setBoolean(14, false);}
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updateAllergies(String id, String allergies)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET allergies = ?"
                    + " WHERE id = ?");
            pst.setString(1, allergies);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updatePrescriptions(String id, String prescriptions)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET prescriptions = ?"
                    + " WHERE id = ?");
            pst.setString(1, prescriptions);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updateConditionsAndNotes(String id, String conditionsAndNotes)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET conditionsAndNotes = ?"
                    + " WHERE id = ?");
            pst.setString(1, conditionsAndNotes);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updateInsurance(String id, String insurance)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET insurance = ?"
                    + " WHERE id = ?");
            pst.setString(1, insurance);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updateAddress(String id, String address)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET address = ?"
                    + " WHERE id = ?");
            pst.setString(1, address);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updatePhoneNumber(String id, String phoneNumber)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET phoneNumber = ?"
                    + " WHERE id = ?");
            pst.setString(1, phoneNumber);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updateDoctor(String id, String doctorID)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET doctorID = ?"
                    + " WHERE id = ?");
            pst.setString(1, doctorID);
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void updateSubmissionPermissions(String id, Boolean submitBlood,
            Boolean submitTemperature, Boolean submitWeight)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE PatientInformation SET "
                    + "submitBlood = ?, submitTemperature = ?, "
                    + "submitWeight = ? WHERE id = ?");
            if(submitBlood){pst.setBoolean(1, true);}
            else {pst.setBoolean(1, false);}
            if(submitTemperature){pst.setBoolean(2, true);}
            else{pst.setBoolean(2, false);}
            if(submitWeight){pst.setBoolean(3, true);}
            else{pst.setBoolean(3, false);}
            pst.setString(4, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void inputProfileMerger(String newID, String ammendedID)
    {
        Connection con = null;
        Statement st = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("INSERT INTO ProfileMerger SET newID = ?,"
                    + "ammendedID = ?");
            pst.setString(1, newID);
            pst.setString(2, ammendedID);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void inputVisitData(String id, float bloodPreasure,
            float temperature, float weight, String medication, String complaints,
            String doctorNotes, String doctorActions)
    {
        Connection con = null;
        Statement st = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("INSERT INTO VisitData SET id = ?, "
                    + "bloodPreasure = ?, temperature = ?, weight = ?, "
                    + "medication = ?, complaints = ?, doctorNotes = ?, "
                    + "doctorActions = ?, valid = True");
            pst.setString(1, id);
            pst.setFloat(2, bloodPreasure);
            pst.setFloat(3, temperature);
            pst.setFloat(4, weight);
            pst.setString(5, medication);
            pst.setString(6, complaints);
            pst.setString(7, doctorNotes);
            pst.setString(8, doctorActions);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static void markVisitValidity(String id, String date, boolean valid)
    {
        Connection con = null;
        PreparedStatement pst = null;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("UPDATE VisitData SET valid = ?"
                    + " WHERE id = ?, date = ?");
            if(valid){pst.setBoolean(1,true);}
            else{pst.setBoolean(1, false);}
            pst.setString(2, id);
            
            pst.executeUpdate();
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }
        }
    }
    
    public static boolean isPatient(String id)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        boolean returnData = false;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ? AND userType = 0");
            pst.setString(1, id);
            rs = pst.executeQuery();
            if(rs.first())
            {   
                   returnData = true;
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static boolean isDoctor(String id)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        boolean returnData = false;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ? AND userType = 1");
            pst.setString(1, id);
            rs = pst.executeQuery();
            if(rs.first())
            {   
                   returnData = true;
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static boolean isNurse(String id)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        boolean returnData = false;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ? AND userType = 2");
            pst.setString(1, id);
            rs = pst.executeQuery();
            if(rs.first())
            {   
                   returnData = true;
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static boolean isAdmin(String id)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        boolean returnData = false;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ? AND userType = 3");
            pst.setString(1, id);
            rs = pst.executeQuery();
            if(rs.first())
            {   
                   returnData = true;
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
    
    public static int getUserType(String id)
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        int returnData = -1;
        
        try{
            con = DriverManager.getConnection(sqlURL, sqlUser, sqlPassword);
            pst = con.prepareStatement("SELECT * FROM LoginData WHERE id = ?");
            pst.setString(1, id);
            rs = pst.executeQuery();
            if(rs.first())
            {   
                   returnData = rs.getInt("userType");
            }
        }
        catch (SQLException e)
        {
            Logger log = Logger.getLogger("DatabaseManager");
            log.log(Level.SEVERE, e.getMessage(), e);
        }
        finally
        {
            try
            {
                if(pst != null)
                {
                    pst.close();
                }
                if(con != null)
                {
                    con.close();
                }
                if(rs!= null)
                {
                    rs.close();
                }
            }
            catch (SQLException e)
            {
                Logger log = Logger.getLogger("DatabaseManager");
                log.log(Level.WARNING, e.getMessage(), e);
            }

        return returnData;
        }
    }
}