package databasecontrollertest;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin Rederick aka 0tter and Robin Yau 
 */
public class LinkedVisitData {
    private String id;
    private String date;
    private float bloodPreasure;
    private float temperature;
    private float weight;
    private String medication;
    private String complaints;
    private String doctorNotes;
    private String doctorActions;
    private Boolean valid;
    private LinkedVisitData previous;
    private LinkedVisitData next;
    
    public LinkedVisitData(String idNum, String d, float bp, float tmp, float w,
            String med, String comp, String dn, String da, Boolean v, LinkedVisitData prev)
    {
        id = idNum;
        date = d;
        bloodPreasure = bp;
        temperature = tmp;
        weight = w;
        medication = med;
        complaints = comp;
        doctorNotes = dn;
        doctorActions = da;
        valid = v;
        previous = prev;
        next = null;
    }
    public void setNext(LinkedVisitData n)
    {
        next = n;
    }
    public String getID()
    {
        return id;
    }
    public String getDate()
    {
        return date;
    }
    public float getBloodPreasure()
    {
        return bloodPreasure;
    }
    public float getTemperature()
    {
        return temperature;
    }
    public float getWeight()
    {
        return weight;
    }
    public String getMedication()
    {
        return medication;
    }
    public String getComplaints()
    {
        return complaints;
    }
    public String getDoctorNotes()
    {
        return doctorNotes;
    }
    public String getDoctorActions()
    {
        return doctorActions;
    }
    public boolean isValid()
    {
        return valid;
    }
    public LinkedVisitData getPrevious()
    {
        return previous;
    }
    public LinkedVisitData getNext()
    {
        return next;
    }
}
