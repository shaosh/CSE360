package databasecontrollertest;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin Rederick aka 0tter and Robin Yau 
 */
public class LinkedPatientInformation {
    private String id;
    private char gender;
    private float height;
    private String allergies;
    private String prescriptions;
    private String conditionsAndNotes;
    private String bloodType;
    private String insurance;
    private String address;
    private String phoneNumber;
    private String doctorID;
    private boolean submitBlood;
    private boolean submitTemperature;
    private boolean submitWeight;
    private LinkedPatientInformation next;
    
    public LinkedPatientInformation(String idNum, char g, float h, String a,
            String p, String can, String bt, String ins, String adr, String phn,
            String dID, boolean sb, boolean st, boolean sw)
    {
        id = idNum;
        gender = g;
        height = h;
        allergies = a;
        prescriptions = p;
        conditionsAndNotes = can;
        bloodType = bt;
        insurance = ins;
        address = adr;
        phoneNumber = phn;
        doctorID = dID;
        submitBlood = sb;
        submitTemperature = st;
        submitWeight = sw;
        next = null;
    }
    public void setNext(LinkedPatientInformation n)
    {
        next = n;
    }
    public String getId()
    {
        return id;
    }
    public char getGender()
    {
        return gender;
    }
    public float getHeight()
    {
        return height;
    }
    public String getAllergies()
    {
        return allergies;
    }
    public String getPrescriptions()
    {
        return prescriptions;
    }
    public String getConditionsAndNotes()
    {
        return conditionsAndNotes;
    }
    public String getBloodType()
    {
        return bloodType;
    }
    public String getInsurance()
    {
        return insurance;
    }
    public String getAddress()
    {
        return address;
    }
    public String getPhoneNumber()
    {
        return phoneNumber;
    }
    public String getDoctorID()
    {
        return doctorID;
    }
    public boolean getBloodPermissions()
    {
        return submitBlood;
    }
    public boolean getTemperaturePermssions()
    {
        return submitTemperature;
    }
    public boolean getWeightPermissions()
    {
        return submitWeight;
    }
    public LinkedPatientInformation getNext()
    {
        return next;
    }
}
