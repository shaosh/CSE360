package gui;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Driver {        
	public static void main(String[] arg){
            while(true)
            {
                if(GUIController.machineState == GUIController.LAUNCH)
                {
                    Welcome welcome =  new Welcome();
                    welcome.WelcomeVisible();
                    GUIController.machineState = GUIController.STARTUP;
                    try {
                        TimeUnit.SECONDS.sleep(5);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if(GUIController.machineState == GUIController.EXIT)
                {
                    System.exit(0);
                }
            }
//		SearchPatient searchPatient =  new SearchPatient();
//		searchPatient.SearchPatientVisible();
//		PatientInfo patientInfo = new PatientInfo();
//		patientInfo.PatientInfoVisible();
	}	
}
 