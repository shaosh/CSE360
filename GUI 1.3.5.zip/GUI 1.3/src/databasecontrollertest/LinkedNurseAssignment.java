package databasecontrollertest;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin Rederick aka Otter
 */
public class LinkedNurseAssignment {
    private String nurseID;
    private String doctorID;
    private LinkedNurseAssignment next;
    
    public LinkedNurseAssignment(String nID, String dID)
    {
        nurseID = nID;
        doctorID = dID;
        next = null;
    }
    public String getNurseID()
    {
        return nurseID;
    }
    public String getDoctorID()
    {
        return doctorID;
    }
    public void setNext(LinkedNurseAssignment n)
    {
        next = n;
    }
    public LinkedNurseAssignment getNext()
    {
        return next;
    }
}
