package databasecontrollertest;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin Rederick aka 0tter and Robin Yau
 */
public class LinkedProfileMerger {
    private String newID;
    private String ammendedID;
    private String date;
    private LinkedProfileMerger next;
    
    public LinkedProfileMerger(String nID, String aID, String d)
    {
        newID = nID;
        ammendedID = aID;
        date = d;
        next = null;
    }
    public void setNext(LinkedProfileMerger n)
    {
        next = n;
    }
    public String getNewID()
    {
        return newID;
    }
    public String getAmmendedID()
    {
        return ammendedID;
    }
    public LinkedProfileMerger getNext()
    {
        return next;
    }
}
